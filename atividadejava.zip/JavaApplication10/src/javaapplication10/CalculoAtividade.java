public class CalculoAtividade {

    public static double calcularValorFuturo(double P, double i, int n) {
        return P * Math.pow(1 + i, n);
    }

    public static double calcularValorPresente(double M, double i, int n) {
        return M / Math.pow(1 + i, n);
    }

    public static void main(String[] args) {
        double P1 = 1200;
        double i1 = 0.09;
        int n1 = 10;

        double P2 = 2000;
        double i2 = 0.10;
        int n2 = 8;

        double montanteFulana = calcularValorFuturo(P1, i1, n1);
        double montanteCiclana = calcularValorFuturo(P2, i2, n2);

        String maisRentavel = montanteFulana > montanteCiclana ? "Fulana" : "Ciclana";

        double M1 = 12000;
        double i3 = 0.09;
        int n3 = 10;

        double M2 = 14000;
        double i4 = 0.10;
        int n4 = 12;

        double presenteFulano = calcularValorPresente(M1, i3, n3);
        double presenteCiclano = calcularValorPresente(M2, i4, n4);

        String maisRentavelPresente = presenteFulano < presenteCiclano ? "Fulano" : "Ciclano";

        System.out.println("--- Atividade 01 ---");
        System.out.printf("Montante de Joana Fulana: $%.2f\n", montanteFulana);
        System.out.printf("Montante de Joana Ciclana: $%.2f\n", montanteCiclana);
        System.out.println("Mais rentável: Joana " + maisRentavel);

        System.out.println("\n--- Atividade 02 ---");
        System.out.printf("Valor presente para João Fulano: $%.2f\n", presenteFulano);
        System.out.printf("Valor presente para João Ciclano: $%.2f\n", presenteCiclano);
        System.out.println("Mais rentável: João " + maisRentavelPresente);
    }
}
